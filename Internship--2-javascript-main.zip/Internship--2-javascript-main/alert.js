let name=prompt("how can i help you?");
document.write( Problem);