

  try {
    const PI = 3.14;
    PI = 3.14;
    document.write(PI);

  }
  catch (err) {
    document.write(err);
  }